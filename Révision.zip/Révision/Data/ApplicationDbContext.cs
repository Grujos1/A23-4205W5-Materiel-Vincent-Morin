﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Révision.Models;
using System.Drawing;
using System.Xml.Linq;

namespace Révision.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            PasswordHasher<IdentityUser> hasher = new PasswordHasher<IdentityUser>();
            IdentityUser admin = new IdentityUser
            {
                Id = "11111111-1111-1111-1111-111111111111",
                UserName = "admin@admin.com",
                Email = "admin@admin.com",
                NormalizedEmail = "ADMIN@ADMIN.COM",
                NormalizedUserName = "ADMIN@ADMIN.COM",
                EmailConfirmed = true
            };
            admin.PasswordHash = hasher.HashPassword(admin, "Passw0rd1");
            builder.Entity<IdentityUser>().HasData(admin);
            builder.Entity<Chat>().HasData(new
            {
                Id = 1,
                Name = "Tucson",
                Image = "https://www.zooplus.ch/fr/magazine/wp-content/uploads/2018/01/kart%C3%A4user-katze-1024x681.jpg"
            });
        }

        public DbSet<Révision.Models.Chat>? Chat { get; set; }
    }
}